# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboard.spec.ts >> live dashboard, policy, emergency, comparison and ROI
- Location: tests\dashboard.spec.ts:3:1

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 45000ms exceeded.
Call log:
  - waiting for getByLabel('Направление', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - link "Smart Traffic AI — главная" [ref=e5] [cursor=pointer]:
      - /url: "#overview"
      - generic [ref=e14]:
        - text: smart traffic
        - generic [ref=e15]: INTELLIGENCE IN MOTION
    - generic [ref=e16]: РАБОЧЕЕ ПРОСТРАНСТВО
    - navigation [ref=e17]:
      - link "Обзор перекрёстка" [ref=e18] [cursor=pointer]:
        - /url: "#overview"
      - link "Видеоаналитика" [ref=e26] [cursor=pointer]:
        - /url: "#analytics"
      - link "AI vs Fixed-Time" [ref=e33] [cursor=pointer]:
        - /url: "#comparison"
      - link "Калибровка ROI" [ref=e42] [cursor=pointer]:
        - /url: "#calibration"
    - button "Подключение" [ref=e46] [cursor=pointer]
    - generic [ref=e50]:
      - generic [ref=e51]: DEMO WORKSPACE
      - generic [ref=e58]:
        - generic [ref=e59]: Mock Hardware
        - generic [ref=e60]: Команды контроллера
      - button "Как показать проект" [ref=e61] [cursor=pointer]
      - generic [ref=e68]:
        - text: SMART TRAFFIC AI
        - generic [ref=e69]: v0.1
  - generic [ref=e70]:
    - banner [ref=e71]:
      - generic [ref=e72]:
        - text: Центр управления
        - generic [ref=e75]: Обзор
      - generic [ref=e76]:
        - generic [ref=e77]: Система онлайн
        - button "Настройки подключения" [ref=e80] [cursor=pointer]
        - generic "Локальная панель оператора" [ref=e84]: OP
    - main [ref=e85]:
      - generic [ref=e86]:
        - generic [ref=e87]:
          - generic [ref=e88]: SMART TRAFFIC AI / CONTROL CENTER
          - heading "Город в движении." [level=1] [ref=e90]
          - paragraph [ref=e91]: Видеть поток. Понимать спрос. Управлять умнее.
        - button "Экспорт данных" [ref=e92] [cursor=pointer]
      - generic [ref=e96]:
        - generic [ref=e97]:
          - generic [ref=e106]:
            - generic [ref=e107]: Перекрёсток 01
            - generic [ref=e108]: simulation
          - generic [ref=e109]: Simulation
        - generic [ref=e110]:
          - generic [ref=e111]: Алгоритм
          - generic [ref=e112]:
            - button "Fixed-Time" [ref=e113] [cursor=pointer]
            - button "Smart AI" [ref=e117] [cursor=pointer]
      - generic [ref=e121]:
        - article [ref=e122]:
          - generic [ref=e123]: Транспорт в очередях
          - generic [ref=e128]: 18объектов
          - generic [ref=e129]: Детерминированная симуляция
        - article [ref=e130]:
          - generic [ref=e131]: Общая очередь
          - generic [ref=e137]: 18машин
          - generic [ref=e138]: Сумма четырёх направлений
        - article [ref=e139]:
          - generic [ref=e140]: Среднее ожидание
          - generic [ref=e145]: 25,1сек
          - generic [ref=e146]: Взвешено по длине очередей
        - article [ref=e147]:
          - generic [ref=e148]: Traffic Score
          - generic [ref=e152]: 26,6баллов
          - generic [ref=e153]: Спрос для адаптивного контроллера
      - generic [ref=e155]:
        - generic [ref=e156]:
          - generic [ref=e157]:
            - generic [ref=e158]:
              - generic [ref=e159]:
                - generic [ref=e160]: ПЕРЕКРЁСТОК 01
                - heading "Движение в реальном времени" [level=2] [ref=e161]
              - generic [ref=e163]:
                - generic [ref=e164]:
                  - button "Схема" [ref=e165] [cursor=pointer]
                  - button "Камера" [disabled] [ref=e173]
                - button "Развернуть перекрёсток" [ref=e177] [cursor=pointer]
            - generic [ref=e187]:
              - img "Схема перекрёстка. Машины показывают количество в очередях, позиции условные." [ref=e188]:
                - generic [ref=e402]:
                  - generic [ref=e403]: WEST
                  - generic [ref=e404]: EAST
                - generic [ref=e405]: "N"
              - generic [ref=e409]: SIMULATION
              - generic [ref=e411]: Позиции условные · очереди из телеметрии
              - generic [ref=e414]:
                - generic [ref=e415]: Движение
                - generic [ref=e417]: Ожидание
            - generic [ref=e419]:
              - generic [ref=e420]: Traffic Simulator
              - generic [ref=e427]: t = 01:19#800
          - generic [ref=e429]:
            - generic [ref=e430]:
              - generic [ref=e431]:
                - heading "Пульс перекрёстка" [level=2] [ref=e432]
                - paragraph [ref=e433]: Последние 90 наблюдений · шаг от 1 секунды
              - combobox "Метрика графика" [ref=e434]:
                - option "Очередь" [selected]
                - option "Ожидание, с"
                - option "Traffic Score"
            - 'img "История: очередь, последнее значение 18" [ref=e435]':
              - generic [ref=e436]:
                - generic [ref=e437]: "33"
                - generic [ref=e438]: "17"
                - generic [ref=e439]: "0"
              - generic [ref=e443]:
                - generic [ref=e444]: 00:38
                - generic [ref=e445]: время источника
                - generic [ref=e446]: 01:19
        - complementary [ref=e447]:
          - generic [ref=e448]:
            - heading "Управление фазами" [level=2] [ref=e450]
            - generic [ref=e454]:
              - generic [ref=e455]: Контроллер активен
              - generic [ref=e456]: ADAPTIVE AI
            - generic [ref=e457]:
              - generic [ref=e462]:
                - generic [ref=e463]: Север ↔ Юг
                - paragraph [ref=e464]: Зелёный
              - strong [ref=e465]:
                - text: "26"
                - generic [ref=e466]: сек
            - generic [ref=e469]:
              - generic [ref=e470]: План зелёного
              - generic [ref=e471]: 45 с
            - generic [ref=e472]:
              - generic [ref=e473]: Север
              - generic [ref=e476]: Юг
              - generic [ref=e479]: Восток
              - generic [ref=e482]: Запад
              - generic [ref=e485]: Пешеходы
            - generic [ref=e488]: Команды Mock-контроллера. Физическое подтверждение не подключено.
            - button "Экстренный приоритет" [ref=e493] [cursor=pointer]
          - generic [ref=e499]:
            - generic [ref=e508]: РЕШЕНИЕ КОНТРОЛЛЕРА
            - heading "Зелёный подстраивается под поток" [level=3] [ref=e509]
            - paragraph [ref=e510]: adaptive
            - generic [ref=e511]:
              - generic [ref=e512]: Входящий поток
              - generic [ref=e513]: 33 об./мин
          - generic [ref=e514]:
            - generic [ref=e519]:
              - heading "Пешеходы" [level=3] [ref=e520]
              - paragraph [ref=e521]: Ожидают перехода
            - strong [ref=e522]: "1"
      - generic [ref=e523]:
        - generic [ref=e524]:
          - generic [ref=e525]:
            - heading "Каждое направление — под контролем" [level=2] [ref=e526]
            - paragraph [ref=e527]: Очереди, ожидание и состав потока
          - generic [ref=e528]: 4 НАПРАВЛЕНИЯ
        - generic [ref=e529]:
          - article [ref=e530]:
            - generic [ref=e531]:
              - heading "Север NORTH INCOMING" [level=3] [ref=e536]:
                - text: Север
                - generic [ref=e537]: NORTH INCOMING
              - generic [ref=e538]: Средняя
            - generic [ref=e539]:
              - generic [ref=e540]:
                - strong [ref=e541]: "9"
                - generic [ref=e542]: в очереди
              - generic [ref=e543]:
                - strong [ref=e544]: 26,3с
                - generic [ref=e545]: ожидание
            - generic [ref=e546]:
              - generic [ref=e547]:
                - text: Макс. ожидание
                - generic [ref=e548]: 36,8 с
              - generic [ref=e549]:
                - text: Поток
                - generic [ref=e550]: 17 /мин
              - generic [ref=e551]:
                - text: Длина
                - generic [ref=e552]: не измеряется
              - generic [ref=e553]:
                - text: Score
                - generic [ref=e554]: 9,8
            - generic [ref=e555]:
              - generic "Легковые" [ref=e556]:
                - text: Легковые
                - generic [ref=e557]: "7"
              - generic "Автобусы" [ref=e558]:
                - text: Автобусы
                - generic [ref=e559]: "0"
              - generic "Грузовики" [ref=e560]:
                - text: Грузовики
                - generic [ref=e561]: "0"
              - generic "Мотоциклы" [ref=e562]:
                - text: Мотоциклы
                - generic [ref=e563]: "2"
              - generic "Велосипеды" [ref=e564]:
                - text: Велосипеды
                - generic [ref=e565]: "0"
              - generic "Пешеходы" [ref=e566]:
                - text: Пешеходы
                - generic [ref=e567]: "0"
          - article [ref=e568]:
            - generic [ref=e569]:
              - heading "Юг SOUTH INCOMING" [level=3] [ref=e574]:
                - text: Юг
                - generic [ref=e575]: SOUTH INCOMING
              - generic [ref=e576]: Низкая
            - generic [ref=e577]:
              - generic [ref=e578]:
                - strong [ref=e579]: "4"
                - generic [ref=e580]: в очереди
              - generic [ref=e581]:
                - strong [ref=e582]: 31,5с
                - generic [ref=e583]: ожидание
            - generic [ref=e584]:
              - generic [ref=e585]:
                - text: Макс. ожидание
                - generic [ref=e586]: 40,2 с
              - generic [ref=e587]:
                - text: Поток
                - generic [ref=e588]: 9 /мин
              - generic [ref=e589]:
                - text: Длина
                - generic [ref=e590]: не измеряется
              - generic [ref=e591]:
                - text: Score
                - generic [ref=e592]: "6"
            - generic [ref=e593]:
              - generic "Легковые" [ref=e594]:
                - text: Легковые
                - generic [ref=e595]: "4"
              - generic "Автобусы" [ref=e596]:
                - text: Автобусы
                - generic [ref=e597]: "0"
              - generic "Грузовики" [ref=e598]:
                - text: Грузовики
                - generic [ref=e599]: "0"
              - generic "Мотоциклы" [ref=e600]:
                - text: Мотоциклы
                - generic [ref=e601]: "0"
              - generic "Велосипеды" [ref=e602]:
                - text: Велосипеды
                - generic [ref=e603]: "0"
              - generic "Пешеходы" [ref=e604]:
                - text: Пешеходы
                - generic [ref=e605]: "0"
          - article [ref=e606]:
            - generic [ref=e607]:
              - heading "Восток EAST INCOMING" [level=3] [ref=e612]:
                - text: Восток
                - generic [ref=e613]: EAST INCOMING
              - generic [ref=e614]: Низкая
            - generic [ref=e615]:
              - generic [ref=e616]:
                - strong [ref=e617]: "3"
                - generic [ref=e618]: в очереди
              - generic [ref=e619]:
                - strong [ref=e620]: 12,1с
                - generic [ref=e621]: ожидание
            - generic [ref=e622]:
              - generic [ref=e623]:
                - text: Макс. ожидание
                - generic [ref=e624]: 31,9 с
              - generic [ref=e625]:
                - text: Поток
                - generic [ref=e626]: 4 /мин
              - generic [ref=e627]:
                - text: Длина
                - generic [ref=e628]: не измеряется
              - generic [ref=e629]:
                - text: Score
                - generic [ref=e630]: 7,1
            - generic [ref=e631]:
              - generic "Легковые" [ref=e632]:
                - text: Легковые
                - generic [ref=e633]: "1"
              - generic "Автобусы" [ref=e634]:
                - text: Автобусы
                - generic [ref=e635]: "1"
              - generic "Грузовики" [ref=e636]:
                - text: Грузовики
                - generic [ref=e637]: "1"
              - generic "Мотоциклы" [ref=e638]:
                - text: Мотоциклы
                - generic [ref=e639]: "0"
              - generic "Велосипеды" [ref=e640]:
                - text: Велосипеды
                - generic [ref=e641]: "0"
              - generic "Пешеходы" [ref=e642]:
                - text: Пешеходы
                - generic [ref=e643]: "0"
          - article [ref=e644]:
            - generic [ref=e645]:
              - heading "Запад WEST INCOMING" [level=3] [ref=e650]:
                - text: Запад
                - generic [ref=e651]: WEST INCOMING
              - generic [ref=e652]: Низкая
            - generic [ref=e653]:
              - generic [ref=e654]:
                - strong [ref=e655]: "2"
                - generic [ref=e656]: в очереди
              - generic [ref=e657]:
                - strong [ref=e658]: 25,8с
                - generic [ref=e659]: ожидание
            - generic [ref=e660]:
              - generic [ref=e661]:
                - text: Макс. ожидание
                - generic [ref=e662]: 33,8 с
              - generic [ref=e663]:
                - text: Поток
                - generic [ref=e664]: 3 /мин
              - generic [ref=e665]:
                - text: Длина
                - generic [ref=e666]: не измеряется
              - generic [ref=e667]:
                - text: Score
                - generic [ref=e668]: 3,7
            - generic [ref=e669]:
              - generic "Легковые" [ref=e670]:
                - text: Легковые
                - generic [ref=e671]: "2"
              - generic "Автобусы" [ref=e672]:
                - text: Автобусы
                - generic [ref=e673]: "0"
              - generic "Грузовики" [ref=e674]:
                - text: Грузовики
                - generic [ref=e675]: "0"
              - generic "Мотоциклы" [ref=e676]:
                - text: Мотоциклы
                - generic [ref=e677]: "0"
              - generic "Велосипеды" [ref=e678]:
                - text: Велосипеды
                - generic [ref=e679]: "0"
              - generic "Пешеходы" [ref=e680]:
                - text: Пешеходы
                - generic [ref=e681]: "0"
      - generic [ref=e682]:
        - generic [ref=e683]:
          - generic [ref=e684]:
            - heading "История переключений" [level=2] [ref=e685]
            - paragraph [ref=e686]: Наблюдаемые изменения за текущий сеанс
          - generic [ref=e687]: Safety Controller
        - generic [ref=e688]:
          - generic [ref=e689]:
            - time [ref=e691]: 01:00
            - generic [ref=e692]: Север ↔ Юг
            - generic [ref=e693]: Зелёный
          - generic [ref=e694]:
            - time [ref=e696]: 00:58
            - generic [ref=e697]: Пешеходы
            - generic [ref=e698]: Все красные
          - generic [ref=e699]:
            - time [ref=e701]: 00:53
            - generic [ref=e702]: Пешеходы
            - generic [ref=e703]: Жёлтый
          - generic [ref=e704]:
            - time [ref=e706]: 00:43
            - generic [ref=e707]: Пешеходы
            - generic [ref=e708]: Зелёный
          - generic [ref=e709]:
            - time [ref=e711]: 00:41
            - generic [ref=e712]: Восток ↔ Запад
            - generic [ref=e713]: Все красные
          - generic [ref=e714]:
            - time [ref=e716]: 00:38
            - generic [ref=e717]: Восток ↔ Запад
            - generic [ref=e718]: Жёлтый
      - generic [ref=e719]:
        - generic [ref=e720]: Vision наблюдает. Decision решает. Safety разрешает.
        - generic [ref=e724]: Smart Traffic AI · локальный прототип
  - dialog "Экстренный приоритет" [ref=e725]:
    - generic [ref=e726]:
      - heading "Экстренный приоритет" [level=2] [ref=e727]
      - button "Закрыть" [active] [ref=e728] [cursor=pointer]
    - generic [ref=e732]:
      - paragraph [ref=e736]: Запросите приоритет для направления. Жёлтый и защитный интервал сохраняются; мгновенного включения зелёного не будет.
      - generic [ref=e737]:
        - generic [ref=e738]:
          - text: Направление
          - combobox "Направление" [ref=e739]:
            - option "Север" [selected]
            - option "Юг"
            - option "Восток"
            - option "Запад"
        - generic [ref=e740]:
          - text: Действие запроса, секунд
          - spinbutton "Действие запроса, секунд" [ref=e741]: "30"
        - button "Запросить приоритет" [ref=e742] [cursor=pointer]
      - button "Отменить активный приоритет" [disabled] [ref=e745]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test('live dashboard, policy, emergency, comparison and ROI',async({page})=>{
  4  |   const errors:string[]=[];
  5  |   page.on('pageerror',e=>errors.push(e.message));
  6  |   await page.goto('/dashboard/');
  7  |   await expect(page.getByText('Система онлайн',{exact:true})).toBeVisible();
  8  |   await expect(page.getByRole('heading',{name:'Город в движении.'})).toBeVisible();
  9  |   await page.getByRole('button',{name:'Fixed-Time',exact:true}).click();
  10 |   await expect.poll(async()=> (await (await page.request.get('/api/v1/system')).json()).policy).toBe('fixed');
  11 |   await page.getByRole('button',{name:'Smart AI',exact:true}).click();
  12 |   await expect.poll(async()=> (await (await page.request.get('/api/v1/system')).json()).policy).toBe('adaptive');
  13 |   await page.getByRole('button',{name:'Экстренный приоритет'}).click();
> 14 |   await page.getByLabel('Направление',{exact:true}).selectOption('east');
     |                                                     ^ Error: locator.selectOption: Test timeout of 45000ms exceeded.
  15 |   await page.getByRole('button',{name:'Запросить приоритет',exact:true}).click();
  16 |   await expect.poll(async()=> (await (await page.request.get('/api/v1/state')).json()).emergency_phase).toBe('east_west');
  17 |   await page.getByRole('button',{name:'Отменить активный приоритет'}).click();
  18 |   await page.getByRole('button',{name:'Закрыть',exact:true}).click();
  19 |   await page.getByRole('link',{name:'AI vs Fixed-Time'}).click();
  20 |   await page.getByRole('button',{name:'Запустить сравнение'}).click();
  21 |   await expect(page.getByText('меньше суммарного ожидания',{exact:true})).toBeVisible({timeout:30000});
  22 |   await expect(page.getByRole('heading',{name:'Результат эксперимента'})).toBeVisible();
  23 |   await page.screenshot({path:'../../.runtime/dashboard-comparison.png',fullPage:true});
  24 |   await page.getByRole('link',{name:'Калибровка ROI'}).click();
  25 |   await page.getByRole('button',{name:'Загрузить ROI'}).click();
  26 |   await expect(page.getByLabel('Конфигурация JSON')).toHaveValue(/"source_id": "demo"/);
  27 |   await expect(page.getByRole('img',{name:'Предпросмотр геометрии камеры'})).toBeVisible();
  28 |   await page.getByRole('link',{name:'Видеоаналитика'}).click();
  29 |   await expect(page.getByRole('heading',{name:'KPI текущей симуляции'})).toBeVisible();
  30 |   await page.getByRole('link',{name:'Обзор перекрёстка'}).click();
  31 |   await page.screenshot({path:'../../.runtime/dashboard-desktop.png',fullPage:true});
  32 |   expect(errors).toEqual([]);
  33 | });
  34 | 
  35 | test('responsive tablet/mobile with no horizontal overflow',async({page})=>{
  36 |   for(const width of [1024,768,390]){
  37 |     await page.setViewportSize({width,height:900});await page.goto('/dashboard/');
  38 |     await expect(page.getByText('Система онлайн',{exact:true})).toBeVisible();
  39 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  40 |     await page.screenshot({path:`../../.runtime/dashboard-${width}.png`,fullPage:true});
  41 |   }
  42 | });
  43 | 
  44 | test('connection loss hides signal confirmation and disables control',async({page})=>{
  45 |   await page.goto('/dashboard/');await expect(page.getByText('Система онлайн',{exact:true})).toBeVisible();
  46 |   await page.context().setOffline(true);
  47 |   await expect(page.getByText('Сигнал неизвестен',{exact:true})).toBeVisible({timeout:12000});
  48 |   await expect(page.getByRole('button',{name:'Fixed-Time',exact:true})).toBeDisabled();
  49 |   await page.context().setOffline(false);
  50 |   await expect(page.getByText('Система онлайн',{exact:true})).toBeVisible({timeout:20000});
  51 | });
  52 | 
```